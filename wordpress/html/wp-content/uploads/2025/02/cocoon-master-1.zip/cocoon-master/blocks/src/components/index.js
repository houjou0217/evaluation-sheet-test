export { default as WidthPanel } from './WidthPanel';
